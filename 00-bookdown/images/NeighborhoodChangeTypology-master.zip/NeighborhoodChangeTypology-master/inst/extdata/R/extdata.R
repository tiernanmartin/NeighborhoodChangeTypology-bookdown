
# EXTERNAL DATASETS LIST --------------------------------------------------

exteral_datasets_list <- NULL # placeholder -- will be updated later

usethis::use_data(exteral_datasets_list)



