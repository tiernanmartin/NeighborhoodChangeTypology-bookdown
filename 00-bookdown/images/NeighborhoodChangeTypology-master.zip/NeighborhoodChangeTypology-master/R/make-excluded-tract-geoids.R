
#' @title Make The List of Excluded Census Tracts
#' @description Temporary description
#' @return a character string
#' @export
make_excluded_tract_geoids <- function(){
  "53033990100"
}
