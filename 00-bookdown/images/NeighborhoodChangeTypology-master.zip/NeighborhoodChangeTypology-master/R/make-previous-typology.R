#' @title Make Previous Typology
#' @description This is a temporary function.
#' @return a MULTIPOLYGON simple feature (class =  `sf`)
#' @export
make_previous_typology <- function(){
  readRDS("extdata/typology.rds")
}
